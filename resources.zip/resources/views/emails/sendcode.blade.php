<!DOCTYPE html>
<html>
<head>
    <title>Code</title>
</head>

<body>
<h2>username: {{$user->username}}</h2>
<h2>Code: {{$user->code}}</h2>
<br/>
This is a email demo from 5balloons.info
</body>

</html>